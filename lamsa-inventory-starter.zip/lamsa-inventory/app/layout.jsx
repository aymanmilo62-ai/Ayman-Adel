import './globals.css';
export const metadata = { title: 'Lamsa Inventory | إدارة المخازن', description: 'نظام لمسة لإدارة المخازن والإنتاج والمحاسبة' };
export default function RootLayout({ children }) { return <html lang="ar" dir="rtl"><body>{children}</body></html>; }
