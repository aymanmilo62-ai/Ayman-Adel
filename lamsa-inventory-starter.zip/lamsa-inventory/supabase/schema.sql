-- Lamsa Inventory ERP - PostgreSQL / Supabase starter schema
create extension if not exists pgcrypto;
create type public.app_role as enum ('owner','system_admin','accountant','warehouse_manager','warehouse_keeper','production_manager','designer','viewer');
create type public.movement_type as enum ('receipt','issue','transfer_out','transfer_in','production_issue','production_receipt','adjustment_in','adjustment_out');
create type public.document_status as enum ('draft','pending','approved','rejected','cancelled');

create table public.companies (
 id uuid primary key default gen_random_uuid(), name text not null, code text unique not null,
 base_currency text not null default 'EGP', created_at timestamptz not null default now()
);
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 company_id uuid not null references public.companies(id), full_name text not null,
 email text not null, role public.app_role not null default 'viewer', is_active boolean not null default true,
 created_at timestamptz not null default now()
);
create table public.warehouses (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 code text not null, name text not null, warehouse_type text not null default 'general',
 location text, manager_id uuid references public.profiles(id), is_active boolean not null default true,
 created_at timestamptz not null default now(), unique(company_id,code)
);
create table public.item_categories (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 name text not null, parent_id uuid references public.item_categories(id), unique(company_id,name)
);
create table public.units (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 name text not null, symbol text not null, unique(company_id,symbol)
);
create table public.items (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 sku text not null, barcode text, name text not null, category_id uuid references public.item_categories(id),
 unit_id uuid not null references public.units(id), item_kind text not null check(item_kind in ('raw_material','finished_good','packaging','spare_part','service')),
 reorder_level numeric(18,3) not null default 0 check(reorder_level>=0), standard_cost numeric(18,4) not null default 0,
 is_active boolean not null default true, created_at timestamptz not null default now(), unique(company_id,sku)
);
create table public.stock_documents (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 document_no text not null, movement public.movement_type not null, status public.document_status not null default 'draft',
 source_warehouse_id uuid references public.warehouses(id), destination_warehouse_id uuid references public.warehouses(id),
 reference_no text, notes text, created_by uuid not null references public.profiles(id), approved_by uuid references public.profiles(id),
 created_at timestamptz not null default now(), approved_at timestamptz, unique(company_id,document_no),
 check(source_warehouse_id is distinct from destination_warehouse_id or source_warehouse_id is null)
);
create table public.stock_document_lines (
 id uuid primary key default gen_random_uuid(), document_id uuid not null references public.stock_documents(id) on delete restrict,
 item_id uuid not null references public.items(id), quantity numeric(18,3) not null check(quantity>0),
 unit_cost numeric(18,4) not null default 0, line_notes text
);
create table public.stock_balances (
 company_id uuid not null references public.companies(id), warehouse_id uuid not null references public.warehouses(id),
 item_id uuid not null references public.items(id), quantity numeric(18,3) not null default 0,
 average_cost numeric(18,4) not null default 0, updated_at timestamptz not null default now(),
 primary key(warehouse_id,item_id)
);
create table public.stock_ledger (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 document_id uuid not null references public.stock_documents(id), line_id uuid not null references public.stock_document_lines(id),
 warehouse_id uuid not null references public.warehouses(id), item_id uuid not null references public.items(id),
 quantity_delta numeric(18,3) not null check(quantity_delta<>0), unit_cost numeric(18,4) not null default 0,
 posted_at timestamptz not null default now(), posted_by uuid not null references public.profiles(id),
 unique(line_id,warehouse_id)
);
create table public.production_orders (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 order_no text not null, product_item_id uuid not null references public.items(id), planned_quantity numeric(18,3) not null check(planned_quantity>0),
 produced_quantity numeric(18,3) not null default 0, status text not null default 'planned' check(status in ('planned','in_progress','completed','cancelled')),
 start_date date, due_date date, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), unique(company_id,order_no)
);
create table public.bill_of_materials (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
 product_item_id uuid not null references public.items(id), component_item_id uuid not null references public.items(id),
 quantity_per_unit numeric(18,6) not null check(quantity_per_unit>0), scrap_percent numeric(6,3) not null default 0,
 unique(product_item_id,component_item_id)
);
create table public.audit_log (
 id bigint generated always as identity primary key, company_id uuid not null references public.companies(id),
 actor_id uuid references public.profiles(id), action text not null, entity text not null, entity_id uuid,
 details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create index idx_items_company_name on public.items(company_id,name);
create index idx_ledger_company_item_date on public.stock_ledger(company_id,item_id,posted_at desc);
create index idx_documents_company_date on public.stock_documents(company_id,created_at desc);
create index idx_production_company_status on public.production_orders(company_id,status);

-- Company isolation helper. Keep all business tables behind authenticated RLS.
create or replace function public.current_company_id() returns uuid language sql stable security definer set search_path=public as $$
 select company_id from public.profiles where id=auth.uid() and is_active=true limit 1;
$$;
create or replace function public.has_any_role(allowed public.app_role[]) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and is_active=true and company_id=public.current_company_id() and role=any(allowed));
$$;

alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.warehouses enable row level security;
alter table public.item_categories enable row level security;
alter table public.units enable row level security;
alter table public.items enable row level security;
alter table public.stock_documents enable row level security;
alter table public.stock_document_lines enable row level security;
alter table public.stock_balances enable row level security;
alter table public.stock_ledger enable row level security;
alter table public.production_orders enable row level security;
alter table public.bill_of_materials enable row level security;
alter table public.audit_log enable row level security;

create policy company_read on public.companies for select to authenticated using(id=public.current_company_id());
create policy profiles_company_read on public.profiles for select to authenticated using(company_id=public.current_company_id());
create policy profiles_admin_manage on public.profiles for all to authenticated using(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin']::public.app_role[])) with check(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin']::public.app_role[]));
create policy warehouses_company_all on public.warehouses for all to authenticated using(company_id=public.current_company_id()) with check(company_id=public.current_company_id());
create policy categories_company_all on public.item_categories for all to authenticated using(company_id=public.current_company_id()) with check(company_id=public.current_company_id());
create policy units_company_all on public.units for all to authenticated using(company_id=public.current_company_id()) with check(company_id=public.current_company_id());
create policy items_company_read on public.items for select to authenticated using(company_id=public.current_company_id());
create policy items_manager_write on public.items for all to authenticated using(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','accountant','warehouse_manager']::public.app_role[])) with check(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','accountant','warehouse_manager']::public.app_role[]));
create policy docs_company_read on public.stock_documents for select to authenticated using(company_id=public.current_company_id());
create policy docs_keeper_create on public.stock_documents for insert to authenticated with check(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','accountant','warehouse_manager','warehouse_keeper','production_manager']::public.app_role[]));
create policy docs_manager_update on public.stock_documents for update to authenticated using(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','accountant','warehouse_manager']::public.app_role[])) with check(company_id=public.current_company_id());
create policy lines_company_access on public.stock_document_lines for all to authenticated using(exists(select 1 from public.stock_documents d where d.id=document_id and d.company_id=public.current_company_id())) with check(exists(select 1 from public.stock_documents d where d.id=document_id and d.company_id=public.current_company_id()));
create policy balances_company_read on public.stock_balances for select to authenticated using(company_id=public.current_company_id());
create policy ledger_company_read on public.stock_ledger for select to authenticated using(company_id=public.current_company_id());
create policy production_company_read on public.production_orders for select to authenticated using(company_id=public.current_company_id());
create policy production_manager_write on public.production_orders for all to authenticated using(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','production_manager','accountant']::public.app_role[])) with check(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','production_manager','accountant']::public.app_role[]));
create policy bom_company_access on public.bill_of_materials for all to authenticated using(company_id=public.current_company_id()) with check(company_id=public.current_company_id());
create policy audit_company_read on public.audit_log for select to authenticated using(company_id=public.current_company_id() and public.has_any_role(array['owner','system_admin','accountant']::public.app_role[]));

-- IMPORTANT: stock posting must be implemented as a server-side transaction/RPC that locks balances,
-- checks available quantities, writes ledger rows, and updates balances atomically. Never allow clients
-- to directly insert/update stock_balances or stock_ledger. Add a SECURITY DEFINER RPC after review.
revoke insert, update, delete on public.stock_balances, public.stock_ledger from anon, authenticated;
